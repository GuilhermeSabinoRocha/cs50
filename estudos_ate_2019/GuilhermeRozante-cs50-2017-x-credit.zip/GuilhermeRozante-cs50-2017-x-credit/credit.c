#include <cs50.h>
#include <stdio.h>

int main(void)
{

printf("Number: ");
long long cc = get_long_long();

int z = cc % 10;
int y = ((cc / 10) % 10);
int x = ((cc / 100) % 10);
int w = ((cc / 1000) % 10);
int u = ((cc / 10000) % 10);
int t = ((cc / 100000) % 10);
int s = ((cc / 1000000) % 10);
int r = ((cc / 10000000) % 10);
int q = ((cc / 100000000) % 10);
int p = ((cc / 1000000000) % 10);
int o = ((cc / 10000000000) % 10);
int n = ((cc / 100000000000) % 10);
int m = ((cc / 1000000000000) % 10);
int l = ((cc / 10000000000000) % 10);
int k = ((cc / 100000000000000) % 10);
int j = ((cc / 1000000000000000) % 10);

int vezes8 = y * 2;
int modulim1 = vezes8 % 10;
int modulim2 = ((vezes8 / 10) % 10);
int modulim3 = modulim1 + modulim2;

int vezes7 = w * 2;
int modulim4 = vezes7 % 10;
int modulim5 = ((vezes7 / 10) % 10);
int modulim6 = modulim4 + modulim5;

int vezes6 = t * 2;
int modulim7 = vezes6 % 10;
int modulim8 = ((vezes6 / 10) % 10);
int modulim9 = modulim8 + modulim7;

int vezes5 = r * 2;
int modulim10 = vezes5 % 10;
int modulim11 = ((vezes5 / 10) % 10);
int modulim12 = modulim10 + modulim11;

int vezes4 = p * 2;
int modulim13 = vezes4 % 10;
int modulim14 = ((vezes4 / 10) % 10);
int modulim15 = modulim13 + modulim14;

int vezes3 = n * 2;
int modulim16 = vezes3 % 10;
int modulim17 = ((vezes3 / 10) % 10);
int modulim18 = modulim16 + modulim17;

int vezes2 = l * 2;
int modulim19 = vezes2 % 10;
int modulim20 = ((vezes2 / 10) % 10);
int modulim21 = modulim19 + modulim20;

int vezes1 = j * 2;
int modulim22 = vezes1 % 10;
int modulim23 = ((vezes1 / 10) % 10);
int modulim24 = modulim22 + modulim23;

int soma1 = modulim3 + modulim6 + modulim9 + modulim12 + modulim15 + modulim18 + modulim21 + modulim24;

int soma2 = soma1 + k + m + o + q + s + u + x + z;

int zero = soma2 % 10;

if (zero == 0 )
{
    if (j == 4)
 
    {
    printf("VISA\n");  
    }
  
    else if (j == 5)
    {
    
        if (k == 1 || k == 2 || k == 3 || k == 4 || k == 5)
        {
    
        printf("MASTERCARD\n");  
        }
    
    }
    
    else if (j == 0)
    {
        if (k == 3 && l == 4)
        {
    
        printf("AMEX\n");  
        }
        
            else if (k == 3 && l == 7)
            {
    
             printf("AMEX\n");  
            }
        
        if (k == 0 && l == 0 && m == 4)
        {
         printf("VISA\n");  
        }
        
    
    }
  
  
}
else
{ 
printf("INVALID\n");  

}









}